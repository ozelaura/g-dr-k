﻿using System.ComponentModel.DataAnnotations;

namespace godrok
{
    internal class Program
    {
        static List<int> depths = new List<int>();


        static void Main(string[] args)
        {
            // 1. feladat
            depths = File.ReadAllLines("melyseg.txt").Select(int.Parse).ToList();
            Console.WriteLine($"1.Feladat\nA fájl adatainak száma:{depths.Count}");
            // 2. feladat
            Console.Write("Adjon meg egy távolságértéket!\t");
            int index = int.Parse(Console.ReadLine() ?? "0");
            Console.WriteLine($"2.Feladat\nEzen a helyen a felszín {GetDepth(index)} méter mélyen van.");

            // 3. feladat
            Console.WriteLine($"3.Feladat\nAz érintetlen terület aránya {Math.Round((double)depths.Count(x => x == 0) / depths.Count * 100, 2)}%.");

            // 4. feladat

            List<List<int>> pits = new List<List<int>>();

            using (StreamWriter writer = new StreamWriter("godrok.txt"))
            {
                List<int> egySor = new List<int>();

                for (int i = 0; i < depths.Count; i++)
                {
                    int ertek = depths[i];

                    if (ertek > 0)
                    {
                        // Új gödör kezdődik
                        egySor.Add(ertek);
                    }

                    if (ertek == 0 && i > 0 && depths[i - 1] > 0)
                    {
                        // Gödör vége, sor hozzáadása
                        writer.WriteLine(string.Join(" ", egySor));
                        pits.Add(egySor);
                        egySor.Clear();
                    }
                }
            }

            // 5. feladat
            Console.WriteLine($"5.Feladat\nA gödrök száma:{pits.Count}");

            // 6. feladat
            var indexes = GetPit(index);

            int start = indexes.Item1;
            int end = indexes.Item2;

            // a)
            Console.WriteLine($"a) A gödör kezdete: {start} méter, a gödör vége: {end} méter.");

            // b)


            // c)
            int maxDepth = depths.GetRange(start, end - start + 1).Max();
            Console.WriteLine($"c) A legnagyobb mélysége {maxDepth} méter.");

            // d)
            int volume = depths.GetRange(start, end - start + 1).Sum();
            Console.WriteLine($"d) A térfogata {volume*10} m^3.");

            // e)
            double safetyVolume = depths.GetRange(start, end - start + 1).Select(x => x - 1).Sum();
            Console.WriteLine($"e) A vízmennyiség {safetyVolume * 10} m^3.");
        }

        static int GetDepth(int index)
        {
            return depths[index];
        }

        static (int, int) GetPit(int index)
        {
            int start = index;
            int end = index;

            while (depths[start] > 0)
            {
                start--;
            }

            while (depths[end] > 0)
            {
                end++;
            }

            return (start, end);
        }

        //static void CalculatePit(int start, int end)
        //{ 
            
        //    for (int i = start; i < end; i++)
        //    {
        //        int a = depths[i];
        //    }
        //}
    }
}
